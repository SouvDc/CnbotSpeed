(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define("DuiCustom", [], factory);
	else if(typeof exports === 'object')
		exports["DuiCustom"] = factory();
	else
		root["DuiCustom"] = factory();
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/lib/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(3)
}
var Component = __webpack_require__(4)(
  /* script */
  __webpack_require__(1),
  /* template */
  __webpack_require__(5),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-5ea52552",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'DuiWikiCard',

  props: {
    message: Object
  },

  methods: {
    handleClick: function handleClick() {
      if (this.message.data.linkUrl) {
        if (/^http/.test(this.message.data.linkUrl)) {
          this.$emit('click', this.message.data.linkUrl);
        } else {
          this.$emit('click', 'http://' + this.message.data.linkUrl);
        }
      }
    },
    handleBtnClick: function handleBtnClick(button) {
      // this.$emit('btnClick', button)
      if (!window.Dui) return;
      window.Dui.send({
        'event': 'recommendation.item.select',
        'data': {
          'text': button && button.name
        }
      });
    },
    handleLoaded: function handleLoaded() {
      this.$emit('loaded');
    }
  },

  computed: {
    btnListClass: function btnListClass() {
      return 'card-wiki--btn-list-' + String(this.message.data.buttons.length > 5 ? 5 : this.message.data.buttons.length);
    }
  }
});

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_card__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_card___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__src_card__);
// import HelloWorld from './src/hello-world'
// import CustomCard from './src/custom-card'
// import gaodeList from './src/gaodeList'
// import gaodeFoodList from './src/gaodeFoodList'
// import foodList from './src/foodList'
// import hotelList from './src/hotelList'
// import placeList from './src/placeList'
// import music from './src/music'
// import weather from './src/weather'


// 导出 install 函数
// Vue.use() 会调用这个函数
var install = function install(Vue) {
  var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  // 如果安装过就忽略
  if (install.installed) return;

  // 指定组件 name
  // Vue.component(HelloWorld.name, HelloWorld)
  // Vue.component(CustomCard.name, CustomCard)
  // Vue.component(gaodeList.widgetName, gaodeList)
  // Vue.component('gaodeFoodList', gaodeFoodList)
  // Vue.component('foodList', foodList)
  // Vue.component('hotelList', hotelList)
  // Vue.component('placeList', placeList)
  // Vue.component('music', music)
  // Vue.component('weather', weather)
  Vue.component('card', __WEBPACK_IMPORTED_MODULE_0__src_card___default.a);
};

// 自动安装 方便打包成压缩文件, 用<script scr=''></script>的方式引用
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

// 把模块导出
/* harmony default export */ __webpack_exports__["default"] = ({
  install: install,
  // helloWorld: HelloWorld,
  // customContentCard: CustomCard
  // gaodeList: gaodeList,
  // gaodeFoodList: gaodeFoodList,
  // gaodeFoodList: foodList,
  // scapeList: placeList,
  // hotelList: hotelList,
  // music: music,
  // weather: weather
  card: __WEBPACK_IMPORTED_MODULE_0__src_card___default.a
});

/***/ }),
/* 3 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 4 */
/***/ (function(module, exports) {

/* globals __VUE_SSR_CONTEXT__ */

// this module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = injectStyles
  }

  if (hook) {
    var functional = options.functional
    var existing = functional
      ? options.render
      : options.beforeCreate
    if (!functional) {
      // inject component registration as beforeCreate hook
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    } else {
      // register for functioal component in vue file
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return existing(h, context)
      }
    }
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [(_vm.message.data.title || _vm.message.data.subTitle) ? _c('div', {
    class: {
      'card-wiki-card': true, 'zoomIn': true, 'has-btns': _vm.message.data.buttons && _vm.message.data.buttons.length > 0
    },
    on: {
      "click": _vm.handleClick
    }
  }, [(_vm.message.data.imageUrl) ? _c('img', {
    staticClass: "card-wiki--img",
    attrs: {
      "src": _vm.img
    },
    on: {
      "load": _vm.handleLoaded
    }
  }) : _vm._e(), _vm._v(" "), (_vm.message.data.title) ? _c('div', {
    staticClass: "card-wiki--title"
  }, [_vm._v(_vm._s(_vm.message.data.title))]) : _vm._e(), _vm._v(" "), (_vm.message.data.subTitle) ? _c('div', {
    staticClass: "card-wiki--text",
    domProps: {
      "innerHTML": _vm._s(_vm.message.data.subTitle)
    }
  }) : _vm._e(), _vm._v(" "), (_vm.message.data.buttons) ? _c('div', {
    staticClass: "card-wiki--bottom"
  }, [_c('div', {
    class: _vm.btnListClass
  }, _vm._l((_vm.message.data.buttons), function(button, index) {
    return (index < 5) ? _c('button', {
      staticClass: "card-wiki-btn",
      on: {
        "click": function($event) {
          $event.stopPropagation();
          _vm.handleBtnClick(button)
        }
      }
    }, [_vm._v(_vm._s(button.name))]) : _vm._e()
  }))]) : _vm._e()]) : _vm._e()])
},staticRenderFns: []}

/***/ })
/******/ ]);
});
//# sourceMappingURL=main.js.map