require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub;' .. playerconf.DUICORE_HOME .. '/corelib.lub'

local gendernode = require 'player.node.gender'
gendernode:run()

